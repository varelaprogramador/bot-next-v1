"use client"

import { CreateProduto } from "@/app/components/create-forms/produto"
import { Badge } from "@/app/components/ui/badge"
import { Button } from "@/app/components/ui/button"
import { ArrowRightIcon, Calendar, CircleDollarSign, Trash2, Plus, Search, Tag, BarChart3 } from "lucide-react"
import { useEffect, useState } from "react"
import type { ProdutosProps } from "../../utils/produto"
import { createClient } from "@/lib/supabase/client"
import { EditProduto } from "@/app/components/edit-form/produto-edit"
import { Input } from "@/app/components/ui/input"
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/app/components/ui/tooltip"

export default function Produtos() {
  const supabase = createClient()
  const [loading, setLoading] = useState(true)
  const [data, setData] = useState<ProdutosProps[]>([])
  const [filterText, setfilterText] = useState("")
  const [filterData, setFilterData] = useState<ProdutosProps[]>([])
  const [filterCategoria, setFilterCategoria] = useState("")

  useEffect(() => {
    const loadData = async () => {
      setLoading(true)
      try {
        const { data, error } = await supabase.from("produtos").select("*")

        if (error) {
          throw error
        }

        setData(data || [])
      } catch (error) {
        console.error("Erro ao carregar dados:", error)
      } finally {
        setLoading(false)
      }
    }

    loadData()
  }, [supabase])

  useEffect(() => {
    const subscription = supabase.channel(`realtime:public:produtos`).on(
      "postgres_changes",
      {
        event: "*",
        schema: "public",
        table: "produtos",
      },
      (payload) => {
        setData((prevData) => {
          switch (payload.eventType) {
            case "INSERT":
              return [...prevData, payload.new as ProdutosProps]
            case "UPDATE":
              return prevData.map((item) => (item.id === payload.new.id ? (payload.new as ProdutosProps) : item))
            case "DELETE":
              return prevData.filter((item) => item.id !== payload.old.id)
            default:
              return prevData
          }
        })
      },
    )

    subscription.subscribe()

    return () => {
      subscription.unsubscribe()
    }
  }, [supabase])

  useEffect(() => {
    if (filterCategoria == "geral") {
      setFilterCategoria("")
    }
    if (filterText && filterCategoria && data) {
      setFilterData(
        data.filter(
          (item) =>
            item.nome.toLowerCase().includes(filterText.toLowerCase()) &&
            item.categoria.toLowerCase() === filterCategoria,
        ),
      )
    } else if (filterText && data) {
      setFilterData(data.filter((item) => item.nome.toLowerCase().includes(filterText.toLowerCase())))
    } else if (filterCategoria && data) {
      setFilterData(data.filter((item) => item.categoria.toLowerCase() === filterCategoria))
    } else {
      setFilterData(data)
    }
  }, [filterText, filterCategoria, data])

  const handleConfirmCreate = async ({ data }: { data: ProdutosProps }) => {
    setLoading(true)
    const { error } = await supabase.from("produtos").insert([data])
    if (error) {
      console.error("Erro ao criar produto:", error)
    } else {
      console.log("Produto criado com sucesso")
    }
    setLoading(false)
  }

  const handleConfirmEdit = async ({ data }: { data: ProdutosProps }) => {
    const { error } = await supabase.from("produtos").update(data).eq("id", data.id)
    if (error) {
      console.error("Erro ao atualizar produto:", error)
    } else {
      console.log("Produto atualizado com sucesso")
    }
  }

  const handleDeleteProduto = async (id: string) => {
    const { error } = await supabase.from("produtos").delete().eq("id", id)

    if (error) {
      console.error("Erro ao deletar produto:", error)
    } else {
      console.log("Produto deletado com sucesso")
      setData((prevData) => prevData.filter((produto) => produto.id !== id))
    }
  }

  // Função para gerar um número aleatório de vendas para demonstração
  const getRandomSales = () => {
    return Math.floor(Math.random() * 100)
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-white">
        <div className="relative w-16 h-16">
          <div className="absolute top-0 left-0 w-full h-full border-4 border-gray-100 rounded-full"></div>
          <div className="absolute top-0 left-0 w-full h-full border-4 border-t-black border-r-transparent border-b-transparent border-l-transparent rounded-full animate-spin"></div>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-white px-4 py-8">
      <div className="">
        <div className="mb-12 text-center">
          <h1 className="text-4xl font-extrabold mb-2 text-black">Área de Produtos</h1>
          <p className="text-gray-500 max-w-2xl mx-auto">
            Gerencie seus produtos, adicione novos itens e acompanhe seu catálogo em um só lugar
          </p>
        </div>

        <div className="flex flex-col md:flex-row gap-4 mb-10 max-w-3xl mx-auto">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <Search size={18} className="text-gray-400" />
            </div>
            <Input
              type="text"
              placeholder="Buscar produtos..."
              className="pl-10 bg-white border border-gray-200 rounded-md focus:ring-2 focus:ring-black focus:border-transparent transition-all"
              onChange={(e) => setfilterText(e.target.value)}
              value={filterText}
            />
          </div>

          <div className="relative">
            <div className="absolute inset-y-0 left-3 flex items-center pointer-events-none">
              <Tag size={18} className="text-gray-400" />
            </div>
            <Select onValueChange={setFilterCategoria} value={filterCategoria}>
              <SelectTrigger className="pl-10 w-full md:w-[220px] bg-white border border-gray-200 rounded-md focus:ring-2 focus:ring-black focus:border-transparent transition-all">
                <SelectValue placeholder="Categoria" />
              </SelectTrigger>
              <SelectContent className="bg-white rounded-md border border-gray-200">
                <SelectGroup>
                  <SelectLabel>Categoria</SelectLabel>
                  <SelectItem value="mensal" className="focus:bg-gray-50">
                    Mensal
                  </SelectItem>
                  <SelectItem value="anual" className="focus:bg-gray-50">
                    Anual
                  </SelectItem>
                  <SelectItem value="geral" className="focus:bg-gray-50">
                    Geral
                  </SelectItem>
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <CreateProduto onConfirmCreate={handleConfirmCreate} />

          {filterData.map((produto) => {
            const vendas = getRandomSales()

            return (
              <TooltipProvider key={produto.id}>
                <Tooltip delayDuration={300}>
                  <TooltipTrigger asChild>
                    <article className="group relative overflow-hidden bg-white rounded-md border border-gray-200 hover:border-black transition-all duration-300 flex flex-col justify-between">
                      <header className="relative z-10 p-6">
                        <div className="flex justify-between items-start mb-3">
                          <h1 className="text-xl font-bold text-black truncate group-hover:underline transition-all">
                            {produto.nome || "Produto teste"}
                          </h1>
                          <Badge
                            className={`${produto.categoria === "mensal" ? "bg-black" : "bg-gray-800"
                              } text-white px-3 py-1 rounded-sm text-xs font-medium`}
                          >
                            {produto.categoria || "categoria"}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 line-clamp-2 h-10">
                          {produto.descricao || "No description provided"}
                        </p>
                      </header>

                      <div className="relative z-10 flex items-center justify-between px-6 py-4 bg-gray-50 text-sm text-gray-600 border-t border-b border-gray-100">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                            <CircleDollarSign size={16} className="text-black" />
                          </div>
                          <div>
                            <div className="text-xs text-gray-500">Valor</div>
                            <div className="font-semibold">R$ {produto.valor || "0"}</div>
                          </div>
                        </div>

                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-gray-100 flex items-center justify-center">
                            <Calendar size={16} className="text-black" />
                          </div>
                          <div>
                            <div className="text-xs text-gray-500">Data</div>
                            <div className="font-medium">{produto.created_at?.split("T")[0] || "No date"}</div>
                          </div>
                        </div>
                      </div>

                      <footer className="relative z-10 p-5 flex gap-2">
                        <Button
                          onClick={() => (window.location.href = `/produtos/${produto.id}`)}
                          className="flex-1 bg-black hover:bg-gray-800 text-white transition-all"
                        >
                          Acessar <ArrowRightIcon size={15} className="ml-1" />
                        </Button>
                        <EditProduto produto={produto} onConfirmEdit={handleConfirmEdit} />
                        <Button
                          onClick={() => handleDeleteProduto(produto?.id || "")}
                          variant={"destructive"}
                          className="bg-red-600 hover:bg-red-700 transition-all"
                        >
                          <Trash2 size={18} />
                        </Button>
                      </footer>

                      <div className="absolute bottom-0 left-0 right-0 h-1 bg-black transform scale-x-0 group-hover:scale-x-100 transition-transform duration-300 origin-left"></div>
                    </article>
                  </TooltipTrigger>
                  <TooltipContent side="top" className="bg-black text-white p-4 rounded-md border-0 shadow-xl max-w-xs">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <h3 className="font-bold">{produto.nome}</h3>
                        <Badge className="bg-white text-black">{produto.categoria}</Badge>
                      </div>
                      <p className="text-sm text-gray-300">{produto.descricao}</p>
                      <div className="grid grid-cols-2 gap-3 pt-2">
                        <div className="flex items-center gap-2">
                          <CircleDollarSign size={16} className="text-gray-300" />
                          <div>
                            <div className="text-xs text-gray-400">Valor</div>
                            <div className="font-medium">R$ {produto.valor || "0"}</div>
                          </div>
                        </div>
                        <div className="flex items-center gap-2">
                          <BarChart3 size={16} className="text-gray-300" />
                          <div>
                            <div className="text-xs text-gray-400">Vendas</div>
                            <div className="font-medium">{vendas} unidades</div>
                          </div>
                        </div>
                      </div>
                      <div className="pt-1 text-xs text-gray-400">Clique para ver mais detalhes e opções</div>
                    </div>
                  </TooltipContent>
                </Tooltip>
              </TooltipProvider>
            )
          })}
        </div>

        {filterData.length === 0 && !loading && (
          <div className="text-center py-16 border border-dashed border-gray-200 rounded-md">
            <div className="w-20 h-20 mx-auto bg-gray-100 rounded-full flex items-center justify-center mb-4">
              <Search size={32} className="text-gray-400" />
            </div>
            <h3 className="text-xl font-bold text-black mb-2">Nenhum produto encontrado</h3>
            <p className="text-gray-500">Tente ajustar seus filtros ou adicione um novo produto</p>
          </div>
        )}
      </div>
    </div>
  )
}
